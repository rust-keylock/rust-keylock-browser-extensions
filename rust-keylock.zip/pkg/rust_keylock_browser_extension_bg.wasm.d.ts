/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const main: () => void;
export const connect_to_rkl: (a: number, b: number) => any;
export const reset_pake: () => any;
export const get_all: () => any;
export const get_filtered: (a: number, b: number) => any;
export const get_decrypted: (a: number, b: number) => any;
export const add: (a: number, b: number) => number;
export const greet: () => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_export_2: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_5: WebAssembly.Table;
export const closure183_externref_shim: (a: number, b: number, c: any) => void;
export const closure214_externref_shim: (a: number, b: number, c: any, d: any) => void;
export const __wbindgen_start: () => void;
